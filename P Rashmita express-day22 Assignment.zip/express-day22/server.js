require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");
const passport = require("passport");
const bcrypt = require("bcrypt");

const app = express();

// Set EJS as view engine
app.set("view engine", "ejs");

// Read form data
app.use(express.urlencoded({ extended: true }));

// Session setup
app.use(
  session({
    secret: "abcd",
    resave: false,
    saveUninitialized: false,
  })
);

//for css
app.use(express.static("public"));


// Passport setup
app.use(passport.initialize());
app.use(passport.session());
require("./config/passportConfig")(passport);

// MongoDB connection
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log(err));

// User model
const User = require("./models/user");

// ---------------- ROUTES -----------------

// Registration page
app.get("/register", (req, res) => {
  res.render("register");
});

// Handle registration
app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;

  // Hash password
  const hashedPw = await bcrypt.hash(password, 10);

  // Save user to DB
  const newUser = new User({
    name,
    email,
    password: hashedPw,
    role: "user",
  });

  await newUser.save();

  res.send(`Registration successful for ${name}`);
});

// Login page
app.get("/login", (req, res) => {
  res.render("login");
});

// Handle login
app.post(
  "/login",
  passport.authenticate("local", {
    successRedirect: "/admin",
    failureRedirect: "/login",
  })
);

// Admin-only middleware
function isAdmin(req, res, next) {
  if (req.isAuthenticated() && req.user.role === "admin") {
    return next();
  }
  res.send("Access Denied");
}

// Admin route
app.get("/admin", isAdmin, (req, res) => {
  res.send("Welcome, Admin!");
});

// Start server
app.listen(4000, () => console.log("Server running on port 4000"));
