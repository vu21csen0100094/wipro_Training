const express = require("express");
const app = express();

app.use(express.json());

// Logging middleware (Challenge 3)
app.use((req, res, next) => {
  const time = new Date().toLocaleString();
  console.log(`[${req.method}] ${req.url} - ${time}`);
  next();
});

// Challenge 1 + 2 routes
app.get("/", (req, res) => {
  res.send("Welcome to Express Server");
});

app.get("/status", (req, res) => {
  res.json({
    server: "running",
    uptime: "OK"
  });
});

app.get("/products", (req, res) => {
  const name = req.query.name;
  if (!name) return res.send("Please provide a product name");
  res.json({ query: name });
});

// Challenge 5 — Import Book Router
const bookRouter = require("./routes/books");
app.use("/books", bookRouter);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

// Error handler
app.use((err, req, res, next) => {
  console.error("Error:", err.stack);
  res.status(500).json({ error: "Internal Server Error" });
});

// Server start
app.listen(4000, () => {
  console.log("Server running on port 4000");
});
