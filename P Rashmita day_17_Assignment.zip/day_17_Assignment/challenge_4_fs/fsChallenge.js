const fs = require('fs').promises;

async function handleFile() {
  try {
    const data = "Node.js is awesome!";

    // Write to file
    await fs.writeFile("feedback.txt", data);
    console.log("Data written successfully.");

    // Read from file
    console.log("Reading file...");
    const fileContent = await fs.readFile("feedback.txt", "utf-8");
    console.log(fileContent);

  } catch (err) {
    console.log("Error:", err);
  }
}

handleFile();
