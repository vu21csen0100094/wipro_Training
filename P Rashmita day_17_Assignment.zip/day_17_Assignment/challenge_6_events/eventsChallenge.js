const EventEmitter = require("events");

const emitter = new EventEmitter();

// Register event listeners
emitter.on("userLoggedIn", (user) => {
  console.log(`User ${user} logged in.`);
});

emitter.on("userLoggedOut", (user) => {
  console.log(`User ${user} logged out.`);
});

emitter.on("sessionExpired", (user) => {
  console.log(`User ${user}'s session expired.`);
});

// Emit events
emitter.emit("userLoggedIn", "John");
emitter.emit("userLoggedOut", "John");

// Bonus: Emit sessionExpired after 5 seconds
setTimeout(() => {
  emitter.emit("sessionExpired", "John");
}, 5000);
