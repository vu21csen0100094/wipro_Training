import { useState } from "react";

export default function useLocalStorage(key, initialValue) {
  const read = () => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  };

  const [value, setValue] = useState(read);

  const save = (val) => {
    const toStore = val instanceof Function ? val(value) : val;
    setValue(toStore);
    localStorage.setItem(key, JSON.stringify(toStore));
  };

  return [value, save];
}
