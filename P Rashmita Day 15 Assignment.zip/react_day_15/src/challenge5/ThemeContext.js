import { createContext, useState, useEffect } from "react";
import useLocalStorage from "./useLocalStorage";

export const ThemeContext = createContext();

export function ThemeProvider({ children }) {
  const [storedTheme, setStoredTheme] = useLocalStorage("theme", "light");
  const [theme, setTheme] = useState(storedTheme);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    setStoredTheme(theme);
  }, [theme, setStoredTheme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === "light" ? "dark" : "light"));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}
