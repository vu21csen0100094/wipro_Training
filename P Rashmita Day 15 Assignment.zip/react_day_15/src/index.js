import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

// IMPORT SERVICE WORKER REGISTRATION
import { register } from "./challenge6/serviceWorkerRegistration";

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// REGISTER SERVICE WORKER HERE
register();

// Measure performance (optional)
reportWebVitals();
