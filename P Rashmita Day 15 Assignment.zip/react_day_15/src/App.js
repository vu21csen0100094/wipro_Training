import React from "react";

// Challenge 5
import { ThemeProvider } from "./challenge5/ThemeContext";
import ThemeToggle from "./challenge5/ThemeToggle";
import "./challenge5/theme.css";

// Challenge 6
import OfflineBanner from "./challenge6/OfflineBanner";

// Challenge 7
import WorkoutTracker from "./challenge7/WorkoutTracker";

function App() {
  return (
    <ThemeProvider>
      <div>
        {/* Challenge 6 */}
        <OfflineBanner />

        <h1>React Challenges Output</h1>

        {/* Challenge 5 */}
        <ThemeToggle />

        <hr />

        {/* Challenge 7 */}
        <WorkoutTracker />
      </div>
    </ThemeProvider>
  );
}

export default App;
