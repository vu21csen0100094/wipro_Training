import { useState, useRef, useEffect } from "react";

export default function useTimer(initialValue = 0) {
  const [seconds, setSeconds] = useState(initialValue);
  const [running, setRunning] = useState(false);
  const intervalRef = useRef();

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setSeconds(sec => sec + 1);
      }, 1000);
    }
    return () => clearInterval(intervalRef.current);
  }, [running]);

  const start = () => setRunning(true);
  const stop = () => setRunning(false);
  const reset = () => setSeconds(0);

  return { seconds, running, start, stop, reset };
}
