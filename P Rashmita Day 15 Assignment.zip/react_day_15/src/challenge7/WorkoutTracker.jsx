import useTimer from "./useTimer";
import { useState } from "react";

export default function WorkoutTracker() {
  const { seconds, running, start, stop, reset } = useTimer();
  const [sets, setSets] = useState(0);

  const completeSet = () => {
    setSets(prev => prev + 1);
    reset();
  };

  return (
    <div>
      <h3>Workout Tracker</h3>
      <p>Sets Completed: {sets}</p>

      <p>Timer: {seconds} sec</p>

      <button onClick={start} disabled={running}>Start</button>
      <button onClick={stop} disabled={!running}>Stop</button>
      <button onClick={reset}>Reset</button>

      <hr />

      <button onClick={completeSet}>Complete Set</button>
    </div>
  );
}
