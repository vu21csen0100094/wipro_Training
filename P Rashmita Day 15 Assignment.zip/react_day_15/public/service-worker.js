const CACHE_NAME = "pwa-cache-v2";

const urlsToCache = [
  "/", 
  "/offline.html"
];

self.addEventListener("install", event => {
  console.log("SW installed");

  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log("Caching offline page");
      return cache.addAll(urlsToCache);
    })
  );

  self.skipWaiting();
});

self.addEventListener("activate", event => {
  console.log("SW activated");
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.map(key => {
          if (key !== CACHE_NAME) return caches.delete(key);
        })
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", event => {
  event.respondWith(
    fetch(event.request).catch(() => {
      return caches.match(event.request).then(cached => {
        return cached || caches.match("/offline.html");
      });
    })
  );
});
