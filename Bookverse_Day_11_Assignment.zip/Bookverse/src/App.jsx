import React, { useRef } from "react";
import BookList from "./components/BookList";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";


function App() {
  const searchRef = useRef(null);

  const focusSearch = () => {
    searchRef.current.focus();
  };

  return (
    <div className="container text-center mt-5">
      <h1 className="mb-3">📚 Welcome to BookVerse</h1>
      <p className="text-muted">Explore popular books and their authors below!</p>

      <div className="mb-4">
        <input
          ref={searchRef}
          type="text"
          className="form-control w-50 mx-auto"
          placeholder="Search books..."
        />
        <button className="btn btn-primary mt-3" onClick={focusSearch}>
          Focus Search Bar
        </button>
      </div>

      <BookList />
    </div>
  );
}

export default App;
