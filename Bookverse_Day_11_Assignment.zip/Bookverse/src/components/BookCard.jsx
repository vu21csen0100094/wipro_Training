import React from "react";
import PropTypes from "prop-types";

function BookCard({ title, author, price, onClick }) {
  return (
    <div
      className="card shadow-sm text-center"
      style={{ cursor: "pointer" }}
      onClick={onClick}
    >
      <div className="card-body">
        {/* 👇 Add this image here */}
        <img
          src="https://img.freepik.com/free-vector/stack-colorful-books_1308-171744.jpg?semt=ais_hybrid&w=740&q=80"
          alt={`${title} cover`}
          className="img-fluid mb-3 rounded"
        />

        <h5 className="card-title">{title}</h5>
        <p className="card-text">
          <strong>Author:</strong> {author}
        </p>
        <p className="card-text">
          <strong>Price:</strong> ₹{price}
        </p>
      </div>
    </div>
  );
}

BookCard.propTypes = {
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  price: PropTypes.number.isRequired,
  onClick: PropTypes.func.isRequired,
};

export default BookCard;
