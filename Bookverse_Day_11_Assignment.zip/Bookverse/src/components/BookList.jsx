import React, { useState, useEffect } from "react";
import BookCard from "./BookCard";
import AuthorInfo from "./AuthorInfo";

function BookList() {
  const [selectedAuthor, setSelectedAuthor] = useState(null);

  const books = [
    
    { id: 2, title: "It Ends With Us", author: "Colleen Hoover", price: 350 },
    { id: 3, title: "The Alchemist", author: "Paulo Coelho", price: 420 },
    { id: 4, title: "Atomic Habits", author: "James Clear", price: 550 },
    { id: 1, title: "The Silent Patient", author: "Alex Michaelides", price: 499 },
    
  ];

  useEffect(() => {
    console.log("📚 Book Data Loaded!");
  }, []);

  return (
    <div className="container">
      <div className="row justify-content-center">
        {books.map((book) => (
          <div key={book.id} className="col-md-3 mb-4">
            <BookCard
              title={book.title}
              author={book.author}
              price={book.price}
              onClick={() => setSelectedAuthor(book.author)}
            />
          </div>
        ))}
      </div>

      {selectedAuthor && <AuthorInfo author={selectedAuthor} />}
    </div>
  );
}

export default BookList;
