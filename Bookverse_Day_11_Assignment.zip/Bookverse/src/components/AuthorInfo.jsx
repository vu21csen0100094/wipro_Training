import React, { Component } from "react";

class AuthorInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      authorBio: "",
      topBooks: [],
    };
  }

  componentDidMount() {
    console.log(`📖 Loading author info for ${this.props.author}`);
    this.loadAuthorData(this.props.author);
  }

  loadAuthorData(author) {
    const authorData = {
      "Alex Michaelides": {
        bio: "Alex Michaelides is a bestselling British–Cypriot author known for psychological thrillers.",
        books: ["The Silent Patient", "The Fury", "The Therapist"],
      },
      "Colleen Hoover": {
        bio: "Colleen Hoover is an American author of romance and YA fiction, famous for emotional storytelling.",
        books: ["It Ends With Us", "Reminders of Him", "Ugly Love"],
      },
      "Paulo Coelho": {
        bio: "Paulo Coelho is a Brazilian lyricist and novelist, best known for inspiring stories of wisdom and hope.",
        books: ["The Alchemist", "Brida", "Eleven Minutes"],
      },
      "James Clear": {
        bio: "James Clear is an American author, entrepreneur, and photographer known for his book Atomic Habits.",
        books: ["Atomic Habits", "Mastering Habits", "The Power of Consistency"],
      },
    };

    const data = authorData[author];
    this.setState({ authorBio: data.bio, topBooks: data.books });
  }

  render() {
    return (
      <div className="card mt-4 p-3">
        <h4>About the Author: {this.props.author}</h4>
        <p>{this.state.authorBio}</p>
        <h6>Top 3 Books:</h6>
        <ul>
          {this.state.topBooks.map((book, index) => (
            <li key={index}>{book}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default AuthorInfo;
