const express = require("express");
const app = express();

// Parse JSON request bodies
app.use(express.json());

// Parse form data sent from HTML forms
app.use(express.urlencoded({ extended: true }));

// Custom logger middleware (logs method, URL, time)
const logger = require("./middleware/logger");
app.use(logger);

// Set EJS as the template/view engine
app.set("view engine", "ejs");

// Set folder where EJS files are stored
app.set("views", "./views");

// Import user routes
const userRoutes = require("./routes/users");
app.use("/users", userRoutes);

// Import course routes
const courseRoutes = require("./routes/courses");
app.use("/courses", courseRoutes);

// Start the server
app.listen(4000, () => {
  console.log("Server running on port 4000");
});
