const express = require("express");
const router = express.Router();
const validateCourseId = require("../middleware/validateCourseId");

// Sample courses array
const courses = [
  { id: 1, name: "React Fundamentals" },
  { id: 2, name: "Node.js Mastery" },
  { id: 3, name: "Express.js Advanced" }
];

// Renders HTML page with course list
router.get("/", (req, res) => {
  res.render("courses", { courses });
});

// Returns JSON when valid course ID is provided
router.get("/:id", validateCourseId, (req, res) => {
  const courseId = req.params.id;

  res.json({
    id: courseId,
    name: "React Mastery",
    duration: "6 weeks"
  });
});

module.exports = router;
