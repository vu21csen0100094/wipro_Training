// Logs method, URL, and timestamp for every request
module.exports = (req, res, next) => {
  const time = new Date().toISOString();
  console.log(`[${req.method}] ${req.url} at ${time}`);
  next();
};
