const express = require("express");
const app = express();

// Home Route
app.get("/", (req, res) => {
  res.send("Welcome to SkillSphere LMS API");
});

// Course Routes
const courseRoutes = require("./routes/courses");
app.use("/courses", courseRoutes);

app.listen(4000, () => {
  console.log("Server running on port 4000");
});
