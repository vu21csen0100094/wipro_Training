const express = require("express");
const router = express.Router();

const validateCourseId = require("../middleware/validateCourseId");

// Dynamic Route With Middleware
router.get("/:id", validateCourseId, (req, res) => {
  const courseId = req.params.id;

  res.json({
    id: courseId,
    name: "React Mastery",
    duration: "6 weeks"
  });
});

module.exports = router;
