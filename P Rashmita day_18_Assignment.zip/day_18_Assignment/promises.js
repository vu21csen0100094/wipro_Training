// promises.js
// Here I am doing the same file reading task but using Promises instead of callbacks
// I will read from input.txt and write the same content into output.txt

const fs = require("fs").promises;

// Step 1: Read the input file
fs.readFile("input.txt", "utf8")
  .then((data) => {
    // Step 2: Write the same data into output.txt
    return fs.writeFile("output.txt", data);
  })
  .then(() => {
    // Step 3: Final success message
    console.log("File copied successfully using Promises!");
  })
  .catch((err) => {
    // Error handling (bonus)
    console.log("Error while copying:", err);
  });
