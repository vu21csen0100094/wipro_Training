// callback.js
// In this file I am trying to understand how callbacks work in Node.js
// I am reading a file and then showing a message after it is read

const fs = require("fs");

console.log("Starting to read the file...");

// Using fs.readFile which works asynchronously
fs.readFile("data.txt", "utf8", (err, data) => {
  // If any error happens while reading
  if (err) {
    console.log("Something went wrong while reading:", err);
    return;
  }

  // Showing the actual content of the file
  console.log("File Content:", data);

  // Adding a small delay to show async behavior (bonus part)
  setTimeout(() => {
    console.log("Read operation completed after delay.");
  }, 1000);
});

// This line prints first just to show that Node.js doesn't wait
console.log("This line runs BEFORE file reading finishes.");
