// asyncAwait.js
// Converting the previous Promise example into async/await
// This code reads input.txt and writes the data into output_async.txt

const fs = require("fs").promises;

async function copyFileAsync() {
  try {
    console.log("Starting async file copy...");

    // Reading the file using await
    const data = await fs.readFile("input.txt", "utf8");

    // Adding an extra delay of 1 second (bonus part)
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Writing the data into output_async.txt
    await fs.writeFile("output_async.txt", data);

    console.log("Async/Await: File copied successfully!");
  } catch (err) {
    // If anything goes wrong, this will catch the error
    console.log("Something went wrong:", err);
  }
}

// Calling the async function
copyFileAsync();
