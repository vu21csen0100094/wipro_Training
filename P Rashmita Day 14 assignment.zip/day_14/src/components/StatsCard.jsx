// StatsCard.jsx
// This card updates only if props actually change

import React from "react";

const StatsCard = React.memo(({ title, value, lastUpdated }) => {
  console.log(`Rendered: ${title}`);
  return (
    <div className="card">
      <h4>{title}</h4>
      <p>{value}</p>
      <small>Last Updated: {lastUpdated}</small>
    </div>
  );
});

export default StatsCard;
