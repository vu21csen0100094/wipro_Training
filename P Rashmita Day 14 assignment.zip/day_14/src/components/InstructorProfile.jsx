// InstructorProfile.jsx
// Lazy loaded component for instructor info

import React from "react";

const InstructorProfile = () => {
  return (
    <div className="module-box">
      <h3>Instructor: Rashmita</h3>
      <p>Senior Frontend Engineer with 5+ years of experience in React.</p>
      <p><b>Courses Taught:</b> React, Node.js, and Express.js</p>
    </div>
  );
};

export default InstructorProfile;
