// CourseDetails.jsx
// This file loads lazily only when clicked

import React from "react";

const CourseDetails = () => {
  return (
    <div className="module-box">
      <h3>📘 React Fundamentals</h3>
      <p>Learn the basics of React including components, props, and state management.</p>
      <p><b>Duration:</b> 4 weeks</p>
      <p><b>Level:</b> Beginner</p>
    </div>
  );
};

export default CourseDetails;
