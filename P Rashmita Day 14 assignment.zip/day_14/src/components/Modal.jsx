// Modal.jsx
// Uses React Portal to render popup outside normal DOM tree

import React from "react";
import ReactDOM from "react-dom";
import "../index.css";

const Modal = ({ onClose }) => {
  return ReactDOM.createPortal(
    <div className="modal-overlay">
      <div className="modal">
        <h3>🔔 Notification</h3>
        <p>New course “Advanced React Patterns” is now available!</p>
        <button onClick={onClose}>Close</button>
      </div>
    </div>,
    document.getElementById("modal-root") // portal target
  );
};

export default Modal;
