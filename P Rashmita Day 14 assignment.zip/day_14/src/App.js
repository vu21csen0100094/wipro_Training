// App.js
// This file connects all four challenges in one small app

import React, { useState, lazy, Suspense } from "react";
import "./index.css";
import StatsCard from "./components/StatsCard";
import ErrorBoundary from "./components/ErrorBoundary";
import Modal from "./components/Modal";

// Lazy loaded components
const CourseDetails = lazy(() => import("./components/CourseDetails"));
const InstructorProfile = lazy(() => import("./components/InstructorProfile"));

function App() {
  const [view, setView] = useState("");
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="App">
      <h2>🎓 LearnSmart – React Advanced Concepts</h2>

      {/* Menu Buttons */}
      <div className="menu">
        <button onClick={() => setView("course")}>View Course Details</button>
        <button onClick={() => setView("instructor")}>View Instructor Profile</button>
        <button onClick={() => setView("stats")}>Dashboard Stats (Pure Component)</button>
        <button onClick={() => setView("error")}>Error Boundary Demo</button>
        <button onClick={() => setShowModal(true)}>Open Notification (Portal)</button>
      </div>

      <hr />

      {/* Lazy Loading Demo */}
      <Suspense fallback={<p>⏳ Loading module...</p>}>
        {view === "course" && <CourseDetails />}
        {view === "instructor" && <InstructorProfile />}
      </Suspense>

      {/* Pure Component Demo */}
      {view === "stats" && (
        <div className="stats-section">
          <StatsCard title="Total Students" value={120} lastUpdated="2 mins ago" />
          <StatsCard title="Active Courses" value={8} lastUpdated="10 mins ago" />
        </div>
      )}

      {/* Error Boundary Demo */}
      {view === "error" && (
        <ErrorBoundary>
          <BrokenComponent />
        </ErrorBoundary>
      )}

      {/* Portal Modal */}
      {showModal && <Modal onClose={() => setShowModal(false)} />}
    </div>
  );
}

// Simulate a broken component for Error Boundary
const BrokenComponent = () => {
  throw new Error("Something went wrong in ProductCard!");
};

export default App;
