const express = require("express");
const app = express();

const courseRoutes = require("./routes/courses");
const errorHandler = require("./middleware/errorHandler");

// Middleware to read JSON body
app.use(express.json());

// Versioned API
app.use("/api/v1/courses", courseRoutes);

// Global error handler
app.use(errorHandler);

// Start server
app.listen(4000, () => {
  console.log("Server running on port 4000");
});
