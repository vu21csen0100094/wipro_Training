const express = require("express");
const router = express.Router();
const { body, validationResult } = require("express-validator");
const rateLimit = require("express-rate-limit");

//course list
let courses = [
  { id: 1, name: "Node.js Basics", duration: "4 weeks" },
  { id: 2, name: "React Mastery", duration: "6 weeks" }
];

// Rate limit: 5 requests/min
const limiter = rateLimit({
  windowMs: 60 * 1000,   // 1 minute
  max: 5,
  message: { error: "Too many requests" }
});

// Apply rate limit to all course routes
router.use(limiter);

// GET all courses
router.get("/", (req, res) => {
  res.json(courses);
});

// POST new course (with validation)
router.post(
  "/",
  [
    body("name").notEmpty().withMessage("Course name is required"),
    body("duration").notEmpty().withMessage("Duration is required")
  ],
  (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.json({ error: errors.array()[0].msg });
    }

    const { name, duration } = req.body;
    const newCourse = {
      id: courses.length + 1,
      name,
      duration
    };

    courses.push(newCourse);
    res.json({ message: "Course added", course: newCourse });
  }
);

// PUT update course
router.put("/:id", (req, res) => {
  const courseId = parseInt(req.params.id);

  let course = courses.find(c => c.id === courseId);
  if (!course) return res.json({ error: "Course not found" });

  course.name = req.body.name || course.name;
  course.duration = req.body.duration || course.duration;

  res.json({ message: "Course updated", course });
});

// DELETE course
router.delete("/:id", (req, res) => {
  const courseId = parseInt(req.params.id);

  courses = courses.filter(c => c.id !== courseId);

  res.json({ message: "Course deleted" });
});

module.exports = router;
