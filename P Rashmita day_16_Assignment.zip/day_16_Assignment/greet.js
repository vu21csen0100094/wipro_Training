// greet.js
// Challenge 3: CLI Greeting App
// Usage: node greet.js Rashmita

const moment = require("moment");

// Take the name from command line arguments
// process.argv[2] is the first user input
const name = process.argv[2] || "Guest";

// Format current date & time
const dateTime = moment().format("ddd MMM D YYYY, hh:mm A");

// Print final message
console.log(`Hello, ${name}! Today is ${dateTime}.`);
