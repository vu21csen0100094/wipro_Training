// hello-node.js
// Challenge 1: Node.js Basics

console.log("Node version:", process.version);
console.log("Current file:", __filename);
console.log("Current directory:", __dirname);

// Print message every 3 seconds
let counter = 0;
const interval = setInterval(() => {
  counter++;
  console.log(`Welcome to Node.js! (Message #${counter})`);
}, 3000);

// Stop after 10 seconds
setTimeout(() => {
  clearInterval(interval);
  console.log("Stopped after 10 seconds.");
}, 10000);
