// app.js
const figlet = require("figlet");
const chalk = require("chalk");

figlet("Welcome to Node.js", function (err, data) {
  if (err) {
    console.log("Error creating banner:", err);
    return;
  }

  console.log(chalk.green(data));
  console.log(chalk.yellow("Enjoy learning Node.js!"));
});
